let questions = [
    {
        question: "What is 2 + 2?",
        A: "3",
        B: "4",
        C: "5",
        correct: "B"
    },
    {
        question: "Which language is used for web?",
        A: "HTML",
        B: "Python",
        C: "C++",
        correct: "A"
    }
];

let index = 0;

function loadQuestion() {
    let q = questions[index];
    document.getElementById("question").innerText = q.question;
    document.getElementById("A").innerText = q.A;
    document.getElementById("B").innerText = q.B;
    document.getElementById("C").innerText = q.C;
}

function checkAnswer(answer) {
    let q = questions[index];

    if (answer === q.correct) {
        document.getElementById("result").innerText = "Correct!";
    } else {
        document.getElementById("result").innerText = "Wrong!";
    }

    index++;

    if (index < questions.length) {
        setTimeout(loadQuestion, 1000);
    } else {
        document.getElementById("question").innerText = "Quiz Finished!";
    }
}

loadQuestion();